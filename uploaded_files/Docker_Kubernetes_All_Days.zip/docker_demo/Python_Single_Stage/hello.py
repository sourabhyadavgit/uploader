import sys
import platform

print("Hello from Python")
print(platform.platform())